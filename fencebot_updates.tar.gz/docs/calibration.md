# Calibration

Three calibration procedures. Run them in this order the first time and
any time the URDF, DH parameters, or mounting changes.

## 1. VR ↔ base-frame alignment

The mock publisher assumes the VR controller position in meters maps 1:1
to the robot's base frame. For a real VR rig this is almost never true —
the headset's origin is usually at the headset position when SteamVR
started, with its own +Y-up convention.

**Procedure:**

1. With the mock publisher on `--pattern static --center 0.5 0.0 0.6`,
   confirm the end-effector converges on approximately `(0.5, 0.0, 0.6)`
   in the Isaac Lab console's `Actual: [...]` line.

2. Switch to real VR. Hold the controller at a measured offset from the
   headset origin (e.g., 50 cm forward, arm extended). Log the raw packet
   with:
   ```bash
   # In a scratch terminal:
   python3 -c "
   import socket, struct
   s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
   s.bind(('0.0.0.0', 5005))
   while True:
       pkt, _ = s.recvfrom(28)
       print(struct.unpack('<7f', pkt))
   "
   ```
   You'll want to redirect VR → this, not VR → the real publisher, for the
   duration of the calibration.

3. Build a rigid transform `T_base←vr` from the recorded samples against
   known base-frame positions. Apply this in the Unity C# side (cleaner)
   or add a transformation node between `vr_udp_publisher` and
   `robot_controller` (uglier but code-only).

## 2. Workspace reachability

Run the sweep:

```bash
# With the full pipeline up
python3 Scripts/calibrate_workspace.py --grid 5
```

This pulses ~125 target poses through the IK + controller and logs each
one to `workspace_report.csv`. Cross-reference with the Isaac Lab console
— any target where "Actual" never converges on "Target" within ~2 cm is
out of reach or too close to a singularity.

Tighten the `x/y/z-range` args until every sampled point is reachable, then
clamp VR targets to that box in `robot_controller.cpp` before forwarding.
(There's no clamp in the current code; this is a known gap noted in
`docs/safety.md`.)

## 3. Contact sensor zero / threshold

The contact sensor on `link6` reports net force in world frame. At rest it
should read near zero; PhysX occasionally reports residual forces from
articulation constraints at a few hundred mN.

**Procedure:**

1. Start the sim, don't send any VR input, let the arm settle (5 seconds).
2. Watch the `run_sim.py` console. It only prints on `hit=True`, which is
   gated by `force_threshold=0.5 N` in `env.get_contact_forces()`.
3. If you see HIT spam with no actual contact, raise the threshold:
   ```python
   contact = env.get_contact_forces(force_threshold=1.5)
   ```
4. If real hits are being missed (e.g., grazing sword strikes), lower it.
   Anything below ~0.2 N is probably noise.

## What's NOT calibrated yet

- Joint-angle offsets vs. URDF zero — assumed correct from the SolidWorks
  export. If joint 1 looks 90° off, this is your first suspect.
- End-effector (sword tip) offset from `link6` origin — currently treated
  as zero. If you add a sword mesh, compose the offset in
  `run_sim.py` before calling `ik_controller.set_command()`.
- Dynamic parameters (link inertias, actuator damping) — inherited from
  the URDF. Not tuned for this project scope.
